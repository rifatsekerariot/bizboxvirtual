module bizbox-mvp

go 1.25.0

require github.com/lxc/incus v0.7.0

require (
	github.com/boombuler/barcode v1.0.1-0.20190219062509-6c824513bacc // indirect
	github.com/golang/protobuf v1.5.4 // indirect
	github.com/google/uuid v1.6.0 // indirect
	github.com/gorilla/schema v1.2.1 // indirect
	github.com/gorilla/securecookie v1.1.2 // indirect
	github.com/gorilla/websocket v1.5.1 // indirect
	github.com/kr/fs v0.1.0 // indirect
	github.com/mattn/go-sqlite3 v1.14.48 // indirect
	github.com/muhlemmer/gu v0.3.1 // indirect
	github.com/pkg/sftp v1.13.6 // indirect
	github.com/pquerna/otp v1.5.0 // indirect
	github.com/sirupsen/logrus v1.9.3 // indirect
	github.com/zitadel/oidc/v2 v2.12.0 // indirect
	golang.org/x/crypto v0.54.0 // indirect
	golang.org/x/net v0.56.0 // indirect
	golang.org/x/oauth2 v0.18.0 // indirect
	golang.org/x/sys v0.47.0 // indirect
	golang.org/x/term v0.45.0 // indirect
	golang.org/x/text v0.40.0 // indirect
	google.golang.org/appengine v1.6.8 // indirect
	google.golang.org/protobuf v1.33.0 // indirect
	gopkg.in/square/go-jose.v2 v2.6.0 // indirect
	gopkg.in/yaml.v2 v2.4.0 // indirect
)
